# Roadmap after the 0.2.0 transfer preview

Implemented in source: automatic local IPv4 discovery/manual IP, protected persistent identities, full-fingerprint enrollment/pinned trust, mutual TLS on TCP and native RFCOMM streams, receiver approval, bounded file/folder streaming, progress, cancellation, verified commit and distributable Windows setup/Android APK. Validation status is separate; physical interop and Bluetooth are not implied by a successful build.

Next gates: physical Windows↔Android TCP/RFCOMM execution, Android native lifecycle/Keystore/provider tests, adapter/driver and clean Windows 10/11 install/upgrade matrices, accessibility and large-file/throughput/disk-fault benchmarking. Independent review of enrollment, pin lifecycle and destination races is required before production claims.

Next features: durable history and named individual trust management; safer pending-offer notifications; Android source-folder selection; reviewed restart journals and authenticated resume; identity rotation and QR-assisted verification; optimized/mobile packaging and commercial signing/store release. Do not enable pause/resume until integrity/source/checkpoint invariants are tested.

Cloud, accounts, subscriptions, HTTP transfer links, internet relay/NAT traversal and other client platforms remain outside this preview. Preserve transport/source/batch policy boundaries for future extensions.