# Security — 0.2.0 transfer preview

The shared engine implements mutual TLS 1.3 with TLS 1.2 fallback, explicit full-fingerprint enrollment, pinned identities, receiver approval and SHA-256-verified commit. This is not an independent audit or a physical interoperability certification. See [validation](VALIDATION.md) and [the operating guide](../MILESTONE2.md).

## Authentication and key storage

Each device generates a persistent RSA-3072 certificate with server/client EKUs and the fixed application SAN dizeredge.local. Certificate validation checks dates, application hostname, RSA size bounds, custom-root chain policy and exact certificate SHA-256 trust. Unknown identities are rejected on incoming connections unless the user opened a 2-minute pairing window. Enrollment requires explicit comparison of all 256 fingerprint bits against the other physical device's identity screen. Outbound unknown peers likewise require comparison. No certificate callback blindly returns true. TLS proves possession of the approved private key and binds the channel to that identity. Discovery IDs and editable names grant no trust.

TLS resumption is disabled; clearing trust cancels active protocol work and requires verification for future sessions. Offline self-signed anchors have no external CRL, so application pin revocation is the relevant revocation mechanism. Certificate lifetime is five years; automated renewal/rotation is not implemented. If a key changes unexpectedly, reject and investigate before pairing anew.

Windows stores the PKCS#12 identity encrypted using current-user DPAPI with atomic file publication. Windows certificate loading uses the current-user key provider for Schannel compatibility. Android encrypts the PKCS#12 identity using AES-256-GCM with a non-exportable Android Keystore wrapping key; its private file is published atomically and Android backup is disabled. Plain private-key buffers are cleared after import. Trust files contain public fingerprints, not private keys. A malicious administrator, rooted device or malware executing as the same user/app UID is outside the confidentiality boundary.

## Threat model and controls

| Threat | Implemented control / remaining boundary |
| --- | --- |
| Spoofed devices / MITM | Exact certificate pinning, full physical-screen comparison on enrollment, mutual TLS; users must actually compare every group |
| Passive interception | TLS on TCP and RFCOMM; only public name/fingerprint/port announcements are plaintext |
| Malicious authenticated peer | Explicit approval of the exact validated manifest; expiry and total-size/count limits |
| Traversal / alternate streams / device names | Shared Windows-safe path validation, case/separator collision and parent-file conflict checks, root containment and no reparse-point destination chain |
| Unauthorized overwrites | Fresh random private staging/final namespace and FileMode.CreateNew; no replacement of existing destinations |
| Partial / corrupted file | Exact declared lengths, source-change checks, per-file SHA-256, sender finish identifier and receiver commit acknowledgement |
| Resource exhaustion | 1 MiB frames, depth 16, 10,000 files, 16 TiB, two sessions, limited unauthenticated attempts, bounded UDP processing, 30-second I/O waits, 90-second approval and handshake deadlines |
| Unsafe temporary data | Windows current-user-only staging ACL; Android private app storage; cleanup on controlled failure/cancellation; abrupt termination can leave an owned .partial directory |
| Local disk exhaustion | Initial free-space check and handled write failure; simultaneous offers do not reserve disk globally |
| Dangerous received content | Never automatically execute/extract; a valid hash does not imply a file is safe to open |
| Sensitive diagnostics | Status/error types only; no keys, pairing secrets or file contents in diagnostic logging; user-visible history includes basic transfer metadata |

Private staging directories are committed by a same-root directory rename after verification. Local same-account filesystem tampering is outside the malicious-peer guarantee; independent review of filesystem race handling remains a release gate. Android export is a separate provider operation after private verification; a failing/noncompliant provider can leave incomplete exports, while the verified originals remain private for retry.

No public HTTP endpoint, cloud service, account, telemetry or internet relay exists. No broad firewall rule is installed. Manual transfers accept private/link-local/loopback IPv4 only; VPN/private routing remains under the user's network configuration. Bluetooth OS pairing is necessary for the native secure links but does not replace the app's identity verification.

## Remaining release gates

Physical Windows↔Android TCP and Bluetooth testing; Android Keystore/TLS/foreground-service execution on device; Windows WinRT compatibility across adapters/packaging models; independent enrollment/destination-writer review; clean-VM installation/uninstallation; benchmark/disk-fault matrices; production signing; durable recovery and identity rotation. Cancellation/retry are implemented; pause/resume, automatic restart recovery and individual named-device management are not. If the final acknowledgement is lost, inspect the receiver before retrying because verified files may already exist.