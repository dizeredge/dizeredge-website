# SFS1 transfer protocol — first active implementation (0.2.0)

All TCP and RFCOMM application traffic below runs inside mutually authenticated TLS. TLS is established before any hello, filename, file size or content is sent. Enrollment validates a complete certificate fingerprint against the other physical screen; UDP and OS pairing are not application identity proofs.

## Control frames

Eight-byte header: ASCII SFS1, then signed Int32 big-endian UTF-8 JSON byte length. Valid lengths are 1–1,048,576 bytes. JSON depth is at most 16; only fixed DTO types are deserialized. Invalid magic, size, JSON, null message or truncated input closes the session. Each direction has one sequential protocol writer. No arbitrary type/object deserialization or executable payload handling exists.

## Session sequence

1. Client sends PeerHello `{Version:1,Name,Fingerprint,Transport}`; server validates the name/version and binds Fingerprint to the actual TLS certificate, then returns its own hello. The receiver replaces any peer-provided transport label with the actual local transport before showing consent.
2. Client sends PeerRequest `{Kind:"pair",Manifest:null}` for pairing-only, or `{Kind:"offer",Manifest:{...}}` for files. Pairing-only receives PeerDecision `{Accepted:true,Message:"Paired"}` and ends without touching a destination. Trust still comes from the TLS fingerprint policy.
3. For offers, validate manifest Version=1, nonempty TransferId, expiry and all files. The request must be unexpired and at most five minutes ahead. The sender creates a four-minute expiry after hashing; clocks should be reasonably aligned. Ask for explicit receiver approval with a 90-second limit. Prepare a safe staging batch before returning Accepted=true; reject or close on preparation failure.
4. Stream exactly each file's declared Int64 length, in manifest order, with no raw-content header or terminator between files. Empty files consume zero bytes. Control bytes cannot be confused with file content because remaining lengths determine every transition. Receiver hashes while writing; sender checks the source again while sending and rejects growth/truncation/digest change.
5. Client sends PeerFinish `{TransferId}` only after every source check succeeded. Receiver requires matching ID and every SHA-256 digest, closes/flushed files and commits the complete batch by directory rename.
6. Receiver emits local verified-receive state and sends PeerDecision Accepted=true only after commit. Sender reports success only after that acknowledgement. A lost acknowledgement can leave a valid receiver folder while the sender reports uncertainty/failure; retry creates a new folder and never overwrites.

Property names use System.Text.Json's default PascalCase and enum values are numeric. Messages are read as their expected DTO at each state; unknown/invalid request kinds or wrong completion IDs fail closed. Product version 0.1.0 had no active listener and is not an interoperable transfer release.

## Manifest and limits

TransferManifest fields: Version, TransferId (GUID string), ExpiresAt (UTC ISO-8601), Files. Each TransferFile contains RelativePath, nonnegative Int64 Length and 64 hexadecimal SHA-256 characters. Limits: 1–10,000 files; total at most 16 TiB; relative path at most 240 characters; serialized control frame at most 1 MiB, so long-name manifests may fit fewer than 10,000 entries. Android sending selection is additionally capped at 100 files.

Reject absolute/UNC/drive/alternate-stream paths, traversal/dot/empty segments, invalid Windows characters/device names, trailing spaces/dots, control characters, case-insensitive normalized duplicates and parent-file conflicts. Preserve relative file structure; do not transmit Android content URIs or local source absolute paths. Empty-directory entries are not defined.

Streaming uses 128 KiB buffers and backpressure, progress at most about five updates per second, sliding-window speed and bounded ETA. Connect deadline is 15 seconds for TCP (Bluetooth app flows use a connection timeout); reads/writes normally have 30-second waits, approval 90 seconds, enrollment handshake at most 110 seconds (10 seconds for closed-pairing incoming TLS), and total protocol work at most 24 hours. Android can impose a shorter foreground-service limit. Cancellation closes the raw transport. No pause/resume or restart-journal message exists; controls must not claim those capabilities.

## Discovery and Bluetooth identifier

LAN: UDP IPv4 multicast 239.255.83.70, default port 45831, TTL 1. JSON announcement fields: Magic="DE-SFS", Version=1, Id=certificate SHA-256, Name, Port=TCP listener. Datagram max 1024 bytes, JSON depth 4, name max 64, ID exactly 64 hex, port 1–65535. Use the datagram source address, never a peer-supplied route. Announce every 3 seconds; deduplicate by ID, expire after 15 seconds of monotonic time, cap 128 cached peers. Announcements are unauthenticated and cannot establish trust.

Bluetooth Classic RFCOMM service UUID: **95762c71-55c1-445d-b07d-c46b945121de**. Windows uses native WinRT service advertising/query/StreamSocket. Android uses listenUsingRfcommWithServiceRecord and createRfcommSocketToServiceRecord. System pairing is performed in OS Settings. Both raw duplex streams feed the identical TLS engine; no BLE or LAN substitution occurs.