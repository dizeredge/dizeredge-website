# DizerEdge - Secure File Sharing for Windows

**0.2.0 transfer preview · Publisher: DizerEdge.** Windows 10 build 19041+ / Windows 11, x64 self-contained release. Native WPF interface; no separate .NET installation is required by the published package.

Use [the shared installation and sharing guide](../MILESTONE2.md). LAN receiving starts with the app; enable pairing explicitly and compare the full identity fingerprints on both screens. Every incoming file offer needs approval. Native Bluetooth RFCOMM is enabled separately and requires system pairing first. Do not infer hardware support from an enabled button: unavailable adapters/drivers/APIs produce an error.

Windows preserves relative folders and saves each verified transfer in a new `Received-…` directory under the download folder. Staging directories receive a private current-user ACL. Junction/reparse-point download paths are rejected. Cancel/retry are implemented; pause/resume is not. Session history shows verified receives and completed sends; durable history is pending.

Settings, DPAPI-protected identity and pinned trust live under `%LOCALAPPDATA%\DizerEdge\SecureFileSharing`. Do not copy the identity to another user/device. Clear paired-device trust and re-verify if an identity changes or is compromised. Uninstall removes the program, preserving downloads and per-user settings/identity data.

Source projects remain App, Core, Network, Bluetooth, Security, Infrastructure and Tests. See [ARCHITECTURE.md](ARCHITECTURE.md), [SECURITY.md](SECURITY.md), [TRANSFER_PROTOCOL.md](TRANSFER_PROTOCOL.md), [BUILD.md](BUILD.md), [TESTING.md](TESTING.md), [VALIDATION.md](VALIDATION.md) and [ROADMAP.md](ROADMAP.md). The original foundation documentation is archived at `docs/history/0.1`.