﻿# Windows 0.2.0 validation — November 11, 2026

## Executed

- Built and published the WPF application in Release with workspace .NET SDK 10.0.404. The win-x64 publish is self-contained.
- Release xUnit: **79 passed, 0 failed, 0 skipped**. Report: `artifacts/TestResults/milestone2.trx`. Includes real mutual-TLS TCP loopback transfers, explicit enrollment/pins, closed pairing, revocation, TLS 1.2 compatibility, rejection, source modification, cancellation/partial cleanup, SHA-256, path/collision validation, malformed framing and UDP discovery/cache expiry.
- TLS over buffered duplex adapters passed a loopback regression. This simulates stream behavior, not Bluetooth hardware. Control frames/duplex writes flush; native WinRT adapters disable default buffering so short TLS records are not held.
- Native WPF tests rendered six pages in both themes at 940×650; previews: `artifacts/ui-m2`. These are application-rendered images, not interactive acceptance.
- Compiled the per-user installer with Inno Setup 6.7.3. An isolated build with a separate test AppId installed the final payload, matched installed DLL hashes to publish output, started the installed WPF application through first content-render, and uninstalled successfully. Process completion was awaited. The test target and uninstall registration were removed. Logs: `artifacts/installer-smoke/*-final.log`.
- Installed `--transport-probe` passed current-user DPAPI identity persistence/certificate validation. Hardware result: **No Bluetooth adapter was found**.
- Delivered setup Authenticode status: **NotSigned**. The compiler vendor's signature does not sign this application or setup.

## Delivered setup

`artifacts/installer/DizerEdge-SecureFileSharing-0.2.0-win-x64.exe`

- Version 0.2.0; Windows 10 build 19041+ / Windows 11, x64.
- Size: 50,395,768 bytes.
- SHA-256: `6dd5e5fab9bdc633f771f3ed295e30d24e03c83a400a5f2cd64ea1ec82a3805d`.
- Optional desktop shortcut, uninstall, bundled runtime; no automatic firewall exception or startup registration.

## Remaining release gates

No physical Windows↔Android or two-PC transfer, physical multicast/Wi-Fi discovery, Bluetooth pairing/file transfer, clean-VM installation matrix, ARM64 package, >4 GiB hardware transfer, throughput benchmark or independent security audit passed here. No Bluetooth adapter was detected and no Android device/emulator was connected. Computer-use initialization was unavailable; no keyboard/mouse or accessibility acceptance is claimed.

Native RFCOMM is implemented and compiled, but hardware interoperability remains unverified. Android native checks are separate in `../Android/VALIDATION.md`. Pause/resume, durable interrupted-transfer recovery/history and named individual trust management remain pending. Process termination can leave private partial files; lost final acknowledgement can leave a valid receiver folder while the sender reports failure. See `../MILESTONE2.md` for installation, pairing and limitations. This is a development preview, not production certification.
