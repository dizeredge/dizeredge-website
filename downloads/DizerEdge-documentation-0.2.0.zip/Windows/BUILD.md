# Windows build and distribution — 0.2.0

Use Windows 10 build 19041+ / Windows 11 and stable .NET 10 SDK. The session uses workspace-local SDK 10.0.404 and Windows SDK 22621/26100. From Windows:

```powershell
dotnet build SecureFileSharing.slnx -c Release
dotnet test SecureFileSharing.slnx -c Release
dotnet publish src/SecureFileSharing.App -c Release -r win-x64 --self-contained true -o artifacts/publish/win-x64
```

For this workspace, substitute `..\.tools\dotnet\dotnet.exe` and set DOTNET_CLI_HOME to `..\.tools\cli`, NUGET_PACKAGES to `..\.tools\packages`, DOTNET_ADD_GLOBAL_TOOLS_TO_PATH=0 and DOTNET_CLI_TELEMETRY_OPTOUT=1. Initial restore/audit needs NuGet access; application operation does not require internet. The complete self-contained output folder is required, not only its EXE. WPF trimming is disabled.

Compile `packaging/SecureFileSharing.iss` with Inno Setup 6.7.3+ ISCC after publishing. Output: `artifacts/installer/DizerEdge-SecureFileSharing-0.2.0-win-x64.exe`. The recipe uses per-user installation, optional desktop shortcut, uninstall support, minimum Windows version and no automatic firewall/startup rules. No real application/installer code-signing certificate is configured. The compiler's own verified vendor signature does not sign the generated application.

The SetupSmokeTest preprocessor flag selects a separate installer AppId for isolated installation testing; never distribute that smoke-test variant as the product installer. Test inside a designated fresh directory, run the installed app's --smoke-test and uninstall that test instance. VALIDATION.md records whether this was actually executed. Clean-VM, upgrades/locked-file cases and signed production distribution remain separate release gates.

Diagnostic commands: `SecureFileSharing.exe --smoke-test` renders the first window and exits; `--transport-probe` checks protected identity persistence and native Bluetooth availability without accepting files. A no-adapter result is not a Bluetooth transfer pass.

For native ARM64, publish a separate win-arm64 folder and validate its OS/driver/installer behavior on hardware. The supplied artifact is x64; x64 emulation on Windows ARM64 is not a native ARM64 certification. Review dependency advisories, run both platform suites, perform physical TCP/RFCOMM acceptance, inspect hashes/logs, obtain an independent security review and configure a real commercial signing process before calling this a production release.