# DizerEdge - Secure File Sharing 0.2.0

This transfer preview implements Windows/Android sending and receiving through local IPv4 TCP and native Bluetooth Classic RFCOMM. Both carry the same mutually authenticated TLS protocol. Local UDP multicast discovers LAN peers; manual local IP connection remains available. This is a development preview, not an independently audited production release.

## Install

- Windows: run `Windows/artifacts/installer/DizerEdge-SecureFileSharing-0.2.0-win-x64.exe`. Per-user installation, optional desktop shortcut, normal uninstall, bundled .NET runtime. No administrator requirement or automatic firewall exception. The application and setup EXE are not commercially code signed.
- Android: install `Android/artifacts/apk/DizerEdge-SecureFileSharing-Android-0.2.0-dev.apk`. Android 8.0+, ARM64/x86-64. This APK uses the existing development signing key, not a production publisher credential. An update preserves app data; uninstall removes private received files and keys. Export wanted files before uninstalling.

See each platform's VALIDATION.md for checks actually executed. Installation on a clean VM/physical phone and physical Bluetooth interoperability are separate release gates, not implied by compilation or an APK signature.

## Share over local Wi-Fi

1. Install the same 0.2.0 version on both devices and connect to the same local Wi-Fi/Ethernet network. Internet access is unnecessary. Windows starts receiving when opened; on Android tap **Start receiving**. Keep both screens open for first pairing and approval.
2. Open **Nearby devices**. Devices should appear within a few seconds. If multicast is blocked, enter the receiver's local IPv4 address on **Send files** instead. Windows displays its addresses in receiving status. Default ports: TCP 45832, UDP 45831.
3. On both devices, enable **Allow pairing for 2 minutes**. Select the target, then choose **Pair device**. On each confirmation screen compare **every fingerprint group** against the identity fingerprint in Settings on the other physical device. Reject any mismatch. Names and discovery advertisements are not authentication.
4. Choose files (Windows also supports selecting a folder), select the paired target, and send. The receiver must accept the exact file offer. Progress shows streamed byte counts/speed with TLS protection; SHA-256 is verified before completion.
5. Windows saves a fresh `Received-…` folder under the configured download directory. Android first commits verified files to private app storage; use **Receive files → Save latest received files to folder** to export through the Android folder picker.

Windows Firewall must permit the app on the intended **Private** network. Do not disable the firewall or open public/internet-facing ports. Wi-Fi client isolation, guest networks, VLANs, VPN routing and blocked multicast can prevent discovery/reachability; manual IP bypasses multicast filtering but cannot bypass network isolation. Only private/link-local/loopback IPv4 transfer endpoints are accepted; public internet addresses are rejected.

## Share over Bluetooth

1. Pair the devices through Windows/Android Bluetooth Settings first. Ensure Bluetooth Classic/RFCOMM support; BLE alone is insufficient.
2. Start receiving in both apps, then enable Bluetooth in both apps. Windows advertises/queries the matching native RFCOMM service UUID. Android lists system-paired devices; matching app-service availability is checked at connection time. OS pairing and app identity verification are distinct steps.
3. Refresh devices, select the Bluetooth target, enable app pairing on both screens, and compare full fingerprints as above. Then send files and accept on the receiver.

Bluetooth uses actual RFCOMM streams, with TLS on top. There is no LAN substitution. Unpaired-device scanning and in-app OS pairing are not implemented: use system Settings. Driver, radio, permissions, Windows WinRT/full-trust compatibility and Android OEM behavior can limit availability; errors leave LAN available. **No physical Bluetooth transfer pass has been recorded on this development host.**

## Safety and current limits

- Two simultaneous protocol sessions; bounded 128 KiB streaming buffers; 1 MiB control frames; up to 10,000 files / 16 TiB in the shared manifest. Android selection is capped at 100 files. Empty files and relative folders are supported; empty-directory-only transfer and Android source-folder selection are not.
- Persistent identity: Windows DPAPI; Android non-exportable Keystore AES key wrapping the TLS private identity. Trust is a pinned certificate SHA-256 hash. Pairing is closed by default, opens for 2 minutes, and requires full fingerprint comparison. **Forget paired devices** clears pins and cancels active protocol sessions.
- Receiver approval expires; reads/writes/connects have deadlines; source changes, bad hashes, invalid names, traversal and collisions fail safely. Each transfer gets a new private staging/final directory; existing files are not replaced. No received file is automatically executed.
- Cancel and retry are supported. Pause/resume is deliberately unavailable. Process termination can leave an owned `.partial` directory, which is not presented as completed; automatic restart recovery and resumable journals are future work. If a completion acknowledgement is lost, the sender may report failure even though a verified receive folder exists; inspect before retrying.
- Android uses a visible data-sync foreground service and a partial wake lock only while work is active. Pairing/approval require the app in the foreground; background offers are rejected. Android may impose service timeouts/battery constraints. The Stop receiving notification action cancels/stops the host. Notification permission can be enabled in Settings on Android 13+.
- Android export creates a new document-provider folder; providers may refuse writes, revoke grants, delay cancellation or leave a partial export after failure. Verified private originals remain available for retry. Extra local-only picker flags cannot guarantee a third-party provider's own offline behavior.
- History is session-only. Individual named-peer management, live protocol recovery, QR pairing, durable history, performance qualification, production signing and independent security review remain pending.

No accounts, cloud service, HTTP file endpoint, internet relay, payment or subscription functionality is included.
