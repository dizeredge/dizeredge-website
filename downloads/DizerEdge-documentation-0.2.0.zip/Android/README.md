# DizerEdge - Secure File Sharing for Android

**0.2.0 transfer preview · Publisher: DizerEdge.** Native C#/.NET 10 Android app, Android 8.0/API 26+, ARM64 and x86-64; target API 36.

Use [the shared installation and sharing guide](../MILESTONE2.md). Tap Start receiving, allow pairing on both screens, compare every fingerprint group, then send and approve files. LAN discovery/manual IP and native Bluetooth Classic RFCOMM share the same mutual-TLS transfer engine. Bluetooth needs system pairing and permission before enabling its receiver; a paired entry is not proof the remote app is currently running.

Android protects the persistent identity with an Android Keystore wrapping key. Selected files use content-provider grants, without broad storage permission. A data-sync foreground service keeps approved work alive when leaving the screen; new pairing/approval requires the app in the foreground. OS battery/service limits still apply.

Verified incoming files are committed to private app storage first. Use Receive files → Save latest received files to folder to export through SAF. Select a local provider. Uninstall removes private copies and keys, so export wanted files first. Transfers can be cancelled/retried; pause/resume and Android source-folder selection are not implemented. Selection is limited to 100 documents; received folder structure is preserved.

See [BUILD.md](BUILD.md), [ARCHITECTURE.md](ARCHITECTURE.md), [SECURITY.md](SECURITY.md), [TESTING.md](TESTING.md), [TRANSFER_PROTOCOL.md](TRANSFER_PROTOCOL.md), [ROADMAP.md](ROADMAP.md) and [VALIDATION.md](VALIDATION.md). The old foundation record is at `docs/history/0.1`. The APK is development signed; no physical-phone or Bluetooth pass is implied by compilation or signing verification.