# Android transfer protocol — 0.2.0

Android uses the exact shared [SFS1 protocol specification](../Windows/TRANSFER_PROTOCOL.md) and implementation. TCP and native Bluetooth RFCOMM both carry mutually authenticated TLS; pairing-only and file-offer requests have the same representation as Windows.

Content URIs and document-provider permission tokens remain local. Android source adapters reopen approved content streams for preparation and sending; changed sources fail the digest/length checks. Received Windows relative folders are validated and committed privately, then optionally exported through a separate SAF writer. A provider URI is never treated as a filesystem path or remote file name.

No Android-specific encryption algorithm, BLE substitute, cloud relay or LAN fallback exists. System Bluetooth pairing does not replace app fingerprint enrollment. Source-folder selection, empty-directory-only transfers, pause/resume and durable restart recovery are not defined by this release.