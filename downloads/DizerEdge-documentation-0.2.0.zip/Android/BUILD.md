# Android build and distribution — 0.2.0

Requires .NET 10 android workload, Android SDK platform 36/build-tools 36.0.0 and compatible JDK. The session uses local SDK 10.0.404, Android workload 36.1.2 and Microsoft OpenJDK 17.0.14+7; Microsoft also recommends JDK 21. No MAUI or Android Studio dependency is required by the app.

From Android:

```powershell
dotnet workload install android
dotnet build src/SecureFileSharing.Android -t:InstallAndroidDependencies -p:AndroidSdkDirectory=C:\android-sdk -p:JavaSdkDirectory=C:\jdk -p:AcceptAndroidSdkLicenses=True
dotnet test tests/SecureFileSharing.Android.Tests -c Release
dotnet publish src/SecureFileSharing.Android -c Release -p:AndroidSdkDirectory=C:\android-sdk -p:JavaSdkDirectory=C:\jdk
```

Keep the sibling Windows source directory: Android references its portable Core, Network and Security projects. Internet is needed for toolchain/initial restore, not for the app's offline local transports. The session's SDK/JDK live at `../.tools/android-sdk` and `../.tools/jdk`; use absolute paths when passing MSBuild properties, quoting paths with spaces. Its .NET executable and caches are the same as described in Windows/BUILD.md.

For signing, use AndroidKeyStore=true plus AndroidSigningKeyStore, AndroidSigningKeyAlias, AndroidSigningStorePass and AndroidSigningKeyPass. The development build uses the existing ignored development keystore and alias dizeredge-development; it is not a commercial publisher identity. Production keys/passwords must be protected and supplied through secure CI, never committed. Increase ApplicationVersion on updates. AAB/Play signing and store submission are future release work.

Copy the signed publish APK to `artifacts/apk/DizerEdge-SecureFileSharing-Android-0.2.0-dev.apk`. Verify with `java -jar <build-tools>/lib/apksigner.jar verify --verbose --print-certs <apk>` and inspect with `aapt2 dump badging <apk>`. Target/minimum: API 36/26; native ABIs ARM64 and x86-64. No .NET runtime installation is needed on the phone. AOT/trimming optimization is deferred until its serialization/native execution can be validated.

Install/launch/pickers/permissions/Keystore/TLS/foreground-service behavior require an actual phone or emulator. Bluetooth requires physical Classic RFCOMM hardware; an emulator or portable loopback suite cannot prove RF interoperability. See VALIDATION.md for executed results.