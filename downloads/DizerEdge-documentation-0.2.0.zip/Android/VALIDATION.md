﻿# Android 0.2.0 validation — November 11, 2026

## Executed

- Published the native Android application in Release with workspace .NET SDK 10.0.404, Android workload 36.1.2, SDK platform 36/build-tools 36.0.0 and Microsoft OpenJDK 17.0.14+7.
- Portable Release xUnit: **93 passed, 0 failed, 0 skipped**. Report: `artifacts/TestResults/milestone2.trx`. Covers Android portable selection/settings/URI metadata/non-seekable hashing and shared manifest/framing, mutual-TLS TCP, trust, rejection, cancellation, integrity, safe destinations and UDP discovery. Shared cases overlap the Windows suite; these are not 172 distinct tests.
- Buffered-duplex TLS regression uses loopback TCP, not Bluetooth. These tests do not execute Android platform APIs.
- Copied the signed publish APK to the delivery directory and verified that exact file with Android SDK apksigner: APK Signature Scheme **v2 and v3 verified**.
- Inspected the APK with aapt2: package/version, minimum/target API, ARM64/x86-64, optional Wi-Fi/Bluetooth hardware, non-exported dataSync service, permissions, disabled backup and no debuggable flag. Logs: `artifacts/apk/*-0.2.0.txt`.

## Delivered APK

`artifacts/apk/DizerEdge-SecureFileSharing-Android-0.2.0-dev.apk`

- Package: `com.dizeredge.securefilesharing`; version name/code: **0.2.0 / 2**.
- Android 8.0/API 26 minimum; target API 36; ARM64 and x86-64.
- Size: 41,740,487 bytes.
- SHA-256: `b92052fd8a6aa06118679ac8bb56b6e54abbd09d1a5fe85e7e4cc395c90cba54`.
- Development signer: `CN=DizerEdge Development, O=DizerEdge Development, C=EG`, RSA 3072. Certificate SHA-256: `ac130e36f406fee1f7b6a5b030f9c3a04147d1b48bc98d8910631bf6d60418a2`.

The APK is development signed, not commercially signed or store published. The private development keystore remains in ignored build artifacts; it is not included in the APK/source delivery.

## Not executed / remaining gates

ADB had no connected Android device/emulator. No Android installation/launch, Keystore reload, native TLS/RFCOMM, physical Wi-Fi discovery/transfer, SAF provider/export, notification, permission, foreground-service/background/rotation or accessibility pass is claimed. Windows detected no Bluetooth adapter. Physical cross-platform transfers remain a release gate despite both adapters compiling.

Test canonical OS files-directory handling on physical API/OEM layouts; shared no-link/path protections remain enabled. Confirm Windows first-use Bluetooth consent, OS pairing, full-fingerprint comparison both ways and both transfer directions with LAN disabled for Bluetooth tests. See TESTING.md.

Android sends individual selected files (up to 100), receives Windows folder structures and explicitly exports verified private files through the system folder picker. Source-folder selection, pause/resume, durable recovery/history and named individual trust management remain pending. Approval requires the app foreground; approved work uses a foreground service subject to OS duration/power limits. Export wanted received files before uninstalling. This is a development preview, not production certification.
