# Android roadmap after 0.2.0

The native client now integrates the shared TCP/RFCOMM TLS engine, discovery/manual IP, Keystore-wrapped identity, explicit trust/approval, streamed file selection, private verified receiving, SAF export and foreground-service lifecycle. APK compilation/signing and portable tests are distinct from Android execution acceptance.

Prioritize physical Android↔Windows Wi-Fi and Classic RFCOMM tests, Keystore reload, source/destination providers, OS permission denial/revocation, background/rotation/process-kill/service-timeout behavior, notifications, accessibility, large files and OEM power policies. Then add source-folder selection, durable history, named trust management, authenticated restart recovery/resume and QR enrollment. Optimize AOT/trimming/size only with native serialization/runtime regression coverage.

Production needs independent security review, current OS/store permission compliance, protected production signing and physical hardware evidence. No account, cloud/relay, internet transfer, payment or subscription is included.